Hi!
  This component allows to call to an COM object with socket using socketserver. 
  In order to use it is due to install the package _ ComMarshallUtils.bpl.
  In order to use the example to make the following steps: 
	  1) Run the TestServer.exe and to close it 
	  2) Run scktsrv.exe and to verify that exists port 211 
	  3) In scktsrv.exe unset the option Registered Objects Only in Connections Menu
	  4) Run Dcomcnfg.exe and select TestComMarsahll Object and set interactive user 
             (this option allows see the TestServer form for this example)
	  5) Run TestClient.exe  write a sentence and Press Send button, then when you read
             the sentence on testserver form press close to close connection.

Note:
	In order to use TComMarshall component you need on client side only the application , 
        ot server side scktsrv.exe and any com object that implements IDispatch.

Manuel Parma
mparma@usa.net
