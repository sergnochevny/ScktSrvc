Improving Midas Pooler Example with One Com Object

This Midas Pooler Example use One Com Object to all connected clients improving memory load and speed.
To use this example you need take from demos\midas\pooler and then remplace pooler.pas for my pooler.pas and add then SingleComObjectFactory.pas unit
This New Factory take control about createinstance to avoid create innecesary com objects. This Factory has a compiler directive to choose a persistent object or non persistent object.
Persistent object will be destroy when the project free the factory.
Non persistent object will be free each time that clients count is 0
This technique use unsupported feature of COM that leave have one COM object to many threads. Please is important your feedback!!
Manuel Parma
mparma@usa.net
